<div class="page-header">
    <h1 class="page-title">SETUP QUERY BUILDER ADAPTER CONNECTION</h1>
    <br/>
    <ol class="breadcrumb breadcrumb-arrow">
        <li class="breadcrumb-item"><a href="javascript:void(0)">Home</a></li>
        <li class="breadcrumb-item active">Database Connection</li>
    </ol>
</div>
<br/>
<div class="page-body">
    <button type = "button" class = "btn btn-primary btn-sm" data-toggle = "modal" data-target = "#tambahDatabase">+ ADD DATABASE CONNECTION</button>
    <br/><br/>
    <table class = "table table-striped table-hover table-bordered" id = "table_driver" data-plugin = "dataTable">
        <thead>
            <th style = "width:5%">#</th>
            <th style = "width:7%">Database Name</th>
            <th style = "width:7%">Database Hostname</th>
            <th style = "width:5%">Database User</th>
            <th style = "width:5%">Date Database Add</th>
            <th style = "width:5%">Date Database Edit</th>
            <th style = "width:5%">Status Connection</th>
            <th style = "width:5%">Action</th>
        </thead>
        <tbody>
        </tbody>
    </table>
</div>
<div class = "modal fade" id = "tambahDatabase">
    <div class = "modal-dialog modal-center">
        <div class = "modal-content">
            <div class = "modal-header">
                <h4>Add Database Connection</h4>
            </div>
            <div class = "modal-body">
                <form action = "<?php echo base_url();?>database/insert" method = "POST">
                    <div class = "form-group">
                        <h5>Database Hostname</h5>
                        <input type = "text" class = "form-control" name = "db_hostname">
                    </div>
                    <div class = "form-group">
                        <h5>Database Name</h5>
                        <input type = "text" class = "form-control" name = "db_name">
                    </div>
                    <div class = "form-group">
                        <h5>Database Username</h5>
                        <input type = "text" class = "form-control" name = "db_username">
                    </div>
                    <div class = "form-group">
                        <h5>Database Password</h5>
                        <input type = "text" class = "form-control" name = "db_password">
                    </div>
                    <button type = "submit" class = "btn btn-primary btn-sm">SUBMIT</button>
                </form>
            </div>
        </div>
    </div>
</div>
