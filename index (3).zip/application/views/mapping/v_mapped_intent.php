<div class="page-header">
    <h1 class="page-title">MAPPED INTENT-QUERY REPOSITORY</h1>
    <br/>
    <ol class="breadcrumb breadcrumb-arrow">
        <li class="breadcrumb-item"><a href="javascript:void(0)">Home</a></li>
        <li class="breadcrumb-item active">Intent Mapped Repository</li>
    </ol>
</div>
<br/>
<?php if($this->session->status_mapping == "success"):?>
    <div class = "alert alert-success alert-dismissible">
        <button type = "button" class = "close" data-dismiss = "alert">&times;</button>
        <?php echo $this->session->msg_mapping;?>
    </div>
<?php elseif($this->session->status_mapping == "error"):?>
    <div class = "alert alert-danger alert-dismissible">
        <button type = "button" class = "close" data-dismiss = "alert">&times;</button>
        <?php echo $this->session->msg_mapping;?>
    </div>
<?php endif;?>
<div class="page-body">
    <button type = "button" class = "btn btn-primary btn-sm" data-toggle = "modal" data-target = "#add_mapping">+ ADD INTENT-QUERY MAPPING</button>
    <a href = "<?php echo base_url();?>mapping/show_intent" target = "_blank" class = "btn btn-light btn-sm">SHOW INTENT REPOSITORY</a>
    <a href = "<?php echo base_url();?>mapping/show_entity" target = "_blank" class = "btn btn-dark btn-sm">SHOW ENTITY REPOSITORY</a>
    <br/><br/>
    <table class = "table table-striped table-hover table-bordered" id = "table_driver" data-plugin = "dataTable">
        <thead>
            <th>#</th>
            <th>Related Entity</th>
            <th>Dataset</th>
            <th>Mapping Status</th>
            <th>Date Mapping Add</th>
            <th>Date Mapping Edit</th>
            <th>Action</th>
        </thead>
        <tbody>
            <?php for($a = 0; $a<count($combination); $a++):?>
            <tr>
                <td><?php echo $a+1;?></td>
                <td>
                    <ul>
                        <?php for($b = 0; $b<count($combination[$a]["entity"]); $b++):?>
                        <li><?php echo $combination[$a]["entity"][$b]["entity_name"];?>: <?php echo $combination[$a]["entity"][$b]["entity_value"];?></li>
                        <?php endfor;?>
                    </ul>
                </td>
                <td><button type = "button" class = "btn btn-primary btn-sm col-lg-12" data-toggle = "modal" data-target ="datasetList" onclick = "loadDataset()">SHOW DATASET</button></td>
                <td>
                    <?php if($combination[$a]["status_aktif_entity_combination"] == 1):?>
                        <button type = "button" class = "btn btn-primary btn-sm col-lg-12">ACTIVE</button>
                    <?php else:?>
                        <button type = "button" class = "btn btn-danger btn-sm col-lg-12">NOT ACTIVE</button>
                    <?php endif;?>
                </td>
                <td><?php echo $combination[$a]["tgl_entity_combination_add"];?></td>
                <td><?php echo $combination[$a]["tgl_entity_combination_edit"];?></td>
                <td>
                    <?php if($combination[$a]["status_aktif_entity_combination"] == 0):?>
                        <a href = "<?php echo base_url();?>mapping/activate/<?php echo $combination[$a]["id_submit_entity_combination"];?>" class = "btn btn-primary btn-sm col-lg-12">ACTIVATE</a>
                    <?php else:?>
                        <a href = "<?php echo base_url();?>mapping/deactive/<?php echo $combination[$a]["id_submit_entity_combination"];?>" class = "btn btn-danger btn-sm col-lg-12">DEACTIVE</a>
                    <?php endif;?>
                    <a href = "<?php echo base_url();?>mapping/edit/<?php echo $combination[$a]["id_submit_entity_combination"];?>" class = "btn btn-primary btn-sm col-lg-12">EDIT MAPPING</a>
                </td>
            </tr>
            <?php endfor;?>
        </tbody>
    </table>
</div>
<div class = "modal fade" id = "add_mapping">
    <div class = "modal-dialog modal-center">
        <div class = "modal-content">
            <div class = "modal-header"></div>
            <div class = "modal-body" style = " max-height: calc(100vh - 210px);overflow-y: auto;">
                <form action = "<?php echo base_url();?>mapping/insert_mapping" method ="POST">
                    <div class = "form-group">
                        <h5>Which <i>Intent</i> do you want to map?</h5>
                        <select class = "form-control" name = "intent" data-plugin ="select2">
                            <?php for($a =0; $a<count($intent); $a++):?>
                            <option value = "<?php echo $intent[$a]["id_submit_entity"];?>"><?php echo $intent[$a]["entity_value"];?></option>
                            <?php endfor;?>
                        </select>
                    </div>
                    <h5>Related <i>Entity / Attributes</i></h5>
                    <table class = "table table-bordered table-hover table-striped">
                        <thead>
                            <th style = "width:10%">#</th>
                            <th>Entity</th>
                            <th>Entity Value</th>
                        </thead>
                        <tbody id = "entity_list">
                            <tr id="entity_button_container">
                                <td colspan =3><button type = "button" class="btn btn-primary btn-sm col-lg-12" onclick = "new_entity_row()">ADD NEW ENTITY</button></td>
                            </tr>
                        </tbody>
                    </table>
                    <div class = "form-group">
                        <h5>Query List</h5>
                        <select class = "form-control" name = "id_dataset" id = "query" data-plugin ="select2" onchange = "load_query()">
                            <option value = 0>New Query</option>
                            <?php for($a =0; $a<count($query); $a++):?>
                            <option value = "<?php echo $query[$a]["id_submit_dataset"];?>"><?php echo $query[$a]["dataset_name"];?></option>
                            <?php endfor;?>
                        </select>
                    </div>
                    <div class = "form-group new_dataset_detail_form">
                        <a href = "<?php echo base_url();?>dataset/add" class = "btn btn-primary btn-sm" target = "_blank">CREATE NEW DATASET</a>
                        <button onclick = "refreshDatasetList()" type = "button" class = "btn btn-primary btn-sm">REFRESH LIST</button>
                    </div>
                    <div class = "form-group">
                        <h5>Query</h5>
                        <textarea name = "dataset_query" required class = "form-control" id ="query_container" readonly></textarea>
                    </div>
                    <button type = "submit" class = "btn btn-primary btn-sm">SUBMIT</button>
                </form>
            </div>
        </div>
    </div>
</div>