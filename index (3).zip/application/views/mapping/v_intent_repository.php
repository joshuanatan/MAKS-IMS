<div class="page-header">
    <h1 class="page-title">INTENT REPOSITORY</h1>
    <br/>
    <ol class="breadcrumb breadcrumb-arrow">
        <li class="breadcrumb-item"><a href="javascript:void(0)">Home</a></li>
        <li class="breadcrumb-item active">Intent Repository</li>
    </ol>
</div>
<br/>
<?php if($this->session->status_intent == "success"):?>
    <div class = "alert alert-success alert-dismissible">
        <button type = "button" class = "close" data-dismiss = "alert">&times;</button>
        <?php echo $this->session->msg_intent;?>
    </div>
<?php elseif($this->session->status_intent == "error"):?>
    <div class = "alert alert-danger alert-dismissible">
        <button type = "button" class = "close" data-dismiss = "alert">&times;</button>
        <?php echo $this->session->msg_intent;?>
    </div>
<?php endif;?>
<div class="page-body">
    <button type = "button" class = "btn btn-primary btn-sm" data-toggle = "modal" data-target = "#newIntent">+ ADD NEW INTENT</button>
    <a href = "<?php echo base_url();?>mapping/show_entity" target = "_blank" class = "btn btn-dark btn-sm">SHOW ENTITY REPOSITORY</a>
    <br/><br/>
    <table class = "table table-striped table-hover table-bordered" id = "table_driver" data-plugin = "dataTable">
        <thead>
            <th style = "width:5%">#</th>
            <th>Intent Name</th>
            <th>Date Intent Add</th>
            <th>Date Intent Edit</th>
            <th style = "width:10%">Status Intent</th>
            <th style = "width:10%">Action</th>
        </thead>
        <tbody>
            <?php for($a = 0; $a<count($intent); $a++):?>
            <tr>
                <td><?php echo $a+1;?></td>
                <td><?php echo $intent[$a]["entity_value"];?></td>
                <td><?php echo $intent[$a]["tgl_entity_add"];?></td>
                <td><?php echo $intent[$a]["tgl_entity_edit"];?></td>
                <td>
                    <?php if($intent[$a]["status_aktif_entity"] == 1):?>
                    <button type = "button" class = "btn btn-primary btn-sm col-lg-12">IN USE</button>
                    <?php else:?>
                    <button type = "button" class = "btn btn-danger btn-sm col-lg-12">NOT IN USE</button>
                    <?php endif;?>
                </td>
                <td>
                    <button type = "button" class = "btn btn-primary btn-sm col-lg-12" data-toggle = "modal" data-target = "#updateIntent<?php echo $a;?>">EDIT INTENT</button>
                    
                    <?php if($intent[$a]["status_aktif_entity"] == 0):?>
                    <a href = "<?php echo base_url();?>mapping/activate_intent/<?php echo $intent[$a]["id_submit_entity"];?>" class = "btn btn-primary btn-sm col-lg-12">ACTIVATE</button>
                    <?php else:?>
                    <a href = "<?php echo base_url();?>mapping/deactive_intent/<?php echo $intent[$a]["id_submit_entity"];?>" class = "btn btn-danger btn-sm col-lg-12">DEACTIVE</button>
                    <?php endif;?>
                </td>
            </tr>
            <?php endfor;?>
        </tbody>
    </table>
    <button type = "button" onclick = "window.close()" class = "btn btn-primary btn-sm">BACK</button>
</div>
<div class = "modal fade" id = "newIntent">
    <div class = "modal-dialog modal-center">
        <div class = "modal-content">
            <div class = "modal-header">
                <h4>New Intent Registration</h4>
            </div>
            <div class = "modal-body">
                <form action = "<?php echo base_url();?>mapping/insert_intent" method = "POST">
                    <div class = "form-group">
                        <h5>Intent Name</h5>
                        <input type = "text" class = "form-control" name = "entity_value">
                        <input type = "hidden" name = "entity_name" value = "intent">
                    </div>
                    <button type = "submit" class = "btn btn-primary btn-sm">SUBMIT</button>
                </form>
            </div>
        </div>
    </div>
</div>
<?php for($a = 0; $a<count($intent); $a++):?>
<div class = "modal fade" id = "updateIntent<?php echo $a;?>">
    <div class = "modal-dialog modal-center">
        <div class = "modal-content">
            <div class = "modal-header">
                <h4>Update Intent</h4>
            </div>
            <div class = "modal-body">
                <form action = "<?php echo base_url();?>mapping/update_intent" method = "POST">
                    <div class = "form-group">
                        <input type = "hidden" name = "id_submit_entity" value = "<?php echo $intent[$a]["id_submit_entity"];?>">
                        <h5>Intent Name</h5>
                        <input type = "text" class = "form-control" name = "entity_value" value = "<?php echo $intent[$a]["entity_value"];?>">
                        <input type = "hidden" name = "entity_name" value = "intent">
                    </div>
                    <button type = "submit" class = "btn btn-primary btn-sm">SUBMIT</button>
                </form>
            </div>
        </div>
    </div>
</div>
<?php endfor;?>