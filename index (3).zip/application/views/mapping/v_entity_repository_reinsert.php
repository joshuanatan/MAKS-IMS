<div class="page-header">
    <h1 class="page-title">ENTITY REPOSITORY</h1>
    <br/>
    <ol class="breadcrumb breadcrumb-arrow">
        <li class="breadcrumb-item"><a href="javascript:void(0)">Home</a></li>
        <li class="breadcrumb-item active">Entity Repository</li>
    </ol>
</div>
<br/>

<div class = "alert alert-danger alert-dismissible">
    <button type = "button" class = "close" data-dismiss = "alert">&times;</button>
    <?php echo validation_errors();?>
</div>
<div class="page-body">
    <form action = "<?php echo base_url();?>mapping/insert_entity" method = "POST">
        <div class = "form-group">
            <h5>Entity Name</h5>
            <input type = "text" class = "form-control" value = "<?php echo set_value("entity_name");?>" name = "entity_name">
        </div>
        <div class = "form-group">
            <h5>Entity Value<i> Separate multiple value with commas [ , ]</i></h5>
            <input type = "text" class = "form-control" value = "<?php echo set_value("entity_value");?>" name = "entity_value">
        </div>
        <button type = "submit" class = "btn btn-primary btn-sm">SUBMIT</button>
        <a href = "<?php echo base_url();?>mapping/show_entity" class = "btn btn-primary btn-sm">BACK</a>
    </form>
</div>
