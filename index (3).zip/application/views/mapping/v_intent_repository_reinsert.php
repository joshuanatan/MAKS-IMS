<div class="page-header">
    <h1 class="page-title">INTENT REPOSITORY</h1>
    <br/>
    <ol class="breadcrumb breadcrumb-arrow">
        <li class="breadcrumb-item"><a href="javascript:void(0)">Home</a></li>
        <li class="breadcrumb-item active">Intent Repository</li>
    </ol>
</div>
<br/>
<div class = "alert alert-danger alert-dismissible">
    <button type = "button" class = "close" data-dismiss = "alert">&times;</button>
    <?php echo validation_errors();?>
</div>
<div class="page-body">
    <form action = "<?php echo base_url();?>mapping/insert_intent" method = "POST">
        <div class = "form-group">
            <h5>Intent Name</h5>
            <input type = "text" class = "form-control" name = "entity_value">
            <input type = "hidden" name = "entity_name" value = "intent">
        </div>
        <button type = "submit" class = "btn btn-primary btn-sm">SUBMIT</button>
        <a href = "<?php echo base_url();?>mapping/show_intent" class = "btn btn-primary btn-sm">BACK</a>
    </form>
</div>
