<script>
function getDatasetQuery(){ //dipake insert add intent
    var id_submit_dataset = $("#listDataset").val();
    $.ajax({
        url:"<?php echo base_url();?>interface/dataset/get_dataset_query",
        dataType:"JSON",
        data:{id_submit_dataset:id_submit_dataset},
        type:"POST",
        success:function(respond){
            console.log(respond);
            $("#datasetQuery").val(respond[0]["dataset_query"]);
        }
    })
}
</script>
<script>
function getDatasetField(){
    var entity = "";
    <?php for($a = 0; $a<count($entity); $a++):?>
    entity += "<option value = '<?php echo $entity[$a]["id_submit_entity"];?>'><?php echo $entity[$a]["entity_name"];?></option>";
    <?php endfor;?>
    var id_dataset = $("#listDataset").val();
    $.ajax({
        url:"<?php echo base_url();?>interface/dataset/get_dataset_dbfield",
        data:{id_dataset:id_dataset},
        dataType:"JSON",
        type:"POST",
        success:function(respond){
            var html = "";
            for(var a = 0; a<respond.length; a++){
                html += "<tr><td>"+(a+1)+"</td><td><input type = 'hidden' name = '' value = '"+respond[a]["id_submit_dataset_dbfield_mapping"]+"'>"+respond[a]["db_field"]+"</td><td><select class = 'form-control' name = ''>"+entity+"</select></td><td><select class = 'form-control'></select></td></tr>"
            }
            $("#tableDatasetField").html(html);
        }
    })
}
</script>
<script>
function getFormula(){
    var id_formula = $("#listFormula").val();
    console.log(id_formula);
    $.ajax({
        url:"<?php echo base_url();?>interface/formula/get_driver_formula_element",
        type:"POST",
        dataType:"JSON",
        data:{id_formula:id_formula},
        success:function(respond){
            var text = "";
            var opsi_element = "";
            for(var a = 0; a<respond.length; a++){
                text += respond[a]["formula_element_name"]+" [Fields] ";
                opsi_element += "<option value = '"+respond[a]["formula_element_name"]+"'>"+respond[a]["formula_element_name"]+"</option>";
            }
            console.log("textnya: "+text);
            $("#formulaQuery").val(text);
            $(".role_element_list_assignment").html(opsi_element);

        }
    }); 
}
</script>