
<script>
function new_entity_row(){
    var opsi = "<option>Choose Entity</option>";
    <?php for($a =0 ; $a<count($entity); $a++):?>
    opsi += "<option value ='<?php echo $entity[$a]["entity_name"];?>'><?php echo $entity[$a]["entity_name"];?></option>";
    <?php endfor;?>

    var counter = $(".new_row").length;
    html = '<tr class = "new_row"><td><div class = "checkbox-custom checkbox-primary"><input type = "checkbox" name = "checks[]" value = '+counter+'><label></label> </div></td><td><select onchange = "get_entity_value('+counter+')" class = "form-control col-lg-12" id = "entity'+counter+'" name = "entity'+counter+'">'+opsi+'</select></td><td><select class = "form-control col-lg-12" id = "entity_value'+counter+'" name = "entity_value'+counter+'"></select></td></tr>';
    $("#entity_button_container").before(html);
}
</script>
<script>
function get_entity_value(row){
    var entity_name = $("#entity"+row).val();
    $.ajax({
        url:"<?php echo base_url();?>interface/entity/get_entity_value_from_entity_name",
        type:"POST",
        dataType:"JSON",
        data:{entity_name:entity_name},
        success:function(respond){
            var html = "";
            for(var a = 0; a<respond.length; a++){
                html += "<option value = '"+respond[a]["id_submit_entity"]+"'>"+respond[a]["entity_value"]+"</option>";
            }
            $("#entity_value"+row).html(html);
        }
    });
}
</script>
<script>
function load_query(){
    var id_query = $("#query").val();
    if(id_query == 0){
        $("#query_container").val("");
        $(".new_dataset_detail_form").css("display","block");
    }
    else{
        $(".new_dataset_detail_form").css("display","none");
        $("#query_container").attr("readonly",true);
        $.ajax({
            url:"<?php echo base_url();?>interface/dataset/get_dataset_query",
            type:"POST",
            dataType:"JSON",
            data:{id_submit_dataset:id_query},
            success:function(respond){
                $("#query_container").val(respond[0]["dataset_query"]);
            } 
        });
    }
}
</script>
<script>
function refreshDatasetList(){
    $.ajax({
        url:"<?php echo base_url();?>interface/dataset/get_dataset_list",
        dataType:"JSON",
        data:{},
        type:"POST",
        success:function(respond){
            var html = "<option value = 0>New Query</option>";
            for(var a = 0; a<respond.length; a++){
                html += "<option value = '"+respond[a]["id_submit_dataset"]+"'>"+respond[a]["dataset_name"]+"</option>";
            }
            $("#query").html(html);
        }
    });
}
</script>