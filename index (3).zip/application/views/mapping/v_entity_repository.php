<div class="page-header">
    <h1 class="page-title">ENTITY REPOSITORY</h1>
    <br/>
    <ol class="breadcrumb breadcrumb-arrow">
        <li class="breadcrumb-item"><a href="javascript:void(0)">Home</a></li>
        <li class="breadcrumb-item active">Entity Repository</li>
    </ol>
</div>
<br/>
<?php if($this->session->status_entity == "success"):?>
    <div class = "alert alert-success alert-dismissible">
        <button type = "button" class = "close" data-dismiss = "alert">&times;</button>
        <?php echo $this->session->msg_entity;?>
    </div>
<?php elseif($this->session->status_entity == "error"):?>
    <div class = "alert alert-danger alert-dismissible">
        <button type = "button" class = "close" data-dismiss = "alert">&times;</button>
        <?php echo $this->session->msg_entity;?>
    </div>
<?php endif;?>
<div class="page-body">
    <button type = "button" class = "btn btn-primary btn-sm" data-toggle = "modal" data-target = "#newEntity">+ ADD NEW ENTITY</button>
    <br/><br/>
    <table class = "table table-striped table-hover table-bordered" id = "table_driver" data-plugin = "dataTable">
        <thead>
            <th style = "width:5%">#</th>
            <th>Entity Name</th>
            <th>Values</th>
            <th>Date Intent Add</th>
            <th>Date Intent Edit</th>
            <th style = "width:10%">Status Intent</th>
            <th style = "width:10%">Action</th>
        </thead>
        <tbody>
            <?php $entity = "";for($a = 0; $a<count($intent); $a++):?>
            <tr>
                <td><?php echo $a+1;?></td>
                <td><?php echo $intent[$a]["entity_name"];?></td>
                <td>
                    <?php $values = explode(",",$intent[$a]["entity_value"]);foreach($values as $value) echo $value."<br/>";?>
                </td>
                <td><?php echo $intent[$a]["tgl_entity_add"];?></td>
                <td><?php echo $intent[$a]["tgl_entity_edit"];?></td>
                <td>
                    <?php if($intent[$a]["status_aktif_entity"] == 1):?>
                    <button type = "button" class = "btn btn-primary btn-sm col-lg-12">IN USE</button>
                    <?php else:?>
                    <button type = "button" class = "btn btn-danger btn-sm col-lg-12">NOT IN USE</button>
                    <?php endif;?>
                </td>
                <td>
                    <button type = "button" class = "btn btn-primary btn-sm col-lg-12" data-toggle = "modal" data-target = "#updateIntent<?php echo $a;?>">EDIT INTENT</button>
                    
                    <?php if($intent[$a]["status_aktif_entity"] == 0):?>
                    <a href = "<?php echo base_url();?>mapping/activate_entity/<?php echo $intent[$a]["entity_name"];?>" class = "btn btn-primary btn-sm col-lg-12">ACTIVATE</a>
                    <?php else:?>
                        <button type = "button" data-toggle = "modal" data-target = "#deleteEntity<?php echo $a;?>" class = "btn btn-danger btn-sm col-lg-12">DEACTIVE</button>
                    <?php endif;?>
                </td>
            </tr>
            <?php endfor;?>
        </tbody>
    </table>
    <button type = "button" onclick = "window.close()" class = "btn btn-primary btn-sm">BACK</button>
</div>
<div class = "modal fade" id = "newEntity">
    <div class = "modal-dialog modal-center">
        <div class = "modal-content">
            <div class = "modal-header">
                <h4>New Entity Registration</h4>
            </div>
            <div class = "modal-body">
                <form action = "<?php echo base_url();?>mapping/insert_entity" method = "POST">
                    <div class = "form-group">
                        <h5>Entity Name</h5>
                        <input type = "text" class = "form-control" name = "entity_name">
                    </div>
                    <div class = "form-group">
                        <h5>Entity Value<i> Separate multiple value with commas [ , ]</i></h5>
                        <input type = "text" class = "form-control" name = "entity_value">
                    </div>
                    <button type = "submit" class = "btn btn-primary btn-sm">SUBMIT</button>
                </form>
            </div>
        </div>
    </div>
</div>
<?php for($a = 0; $a<count($intent); $a++):?>
<div class = "modal fade" id = "updateIntent<?php echo $a;?>">
    <div class = "modal-dialog modal-center">
        <div class = "modal-content">
            <div class = "modal-header">
                <h4>Update Entity</h4>
            </div>
            <div class = "modal-body">
                <form action = "<?php echo base_url();?>mapping/update_entity" method = "POST">
                    <input type = "hidden" name = "entity_name_control" value = "<?php echo $intent[$a]["entity_name"];?>">
                    <div class = "form-group">
                        <h5>Entity Name</h5>
                        <input type = "text" class = "form-control" name = "entity_name" value = "<?php echo $intent[$a]["entity_name"];?>">
                    </div>
                    <h5>Values</h5>
                    <table class = "table table-bordered table-hover table-striped">
                        <thead>
                            <th style = "width:5%">Remove</th>
                            <th>Values</th>
                        </thead>
                        <tbody>
                            <?php 
                            $id_submit_entity = explode(",",$intent[$a]["id_submit_entity"]);
                            $entity_value = explode(",",$intent[$a]["entity_value"]);
                            for($b = 0; $b<count($id_submit_entity); $b++):?>
                            <tr>
                                <td>
                                    <div class = "checkbox-custom checkbox-primary">
                                        <input type = "checkbox" value = "<?php echo $id_submit_entity[$b];?>" name = "check_remove[]">
                                        <label></label>
                                    </div>
                                </td>
                                <td><?php echo $entity_value[$b];?></td>
                            </tr>
                            <?php endfor;?>
                        </tbody>
                    </table>
                    <div class = "form-group">
                        <h5>New Values <i>Separate by Comma (,)</i></h5>
                        <input type = "text" class = "form-control" name = "entity_value">
                    </div>
                    <button type = "submit" class = "btn btn-primary btn-sm">SUBMIT</button>
                </form>
            </div>
        </div>
    </div>
</div>
<div class = "modal fade" id = "deleteEntity<?php echo $a;?>">
    <div class = "modal-dialog modal-center">
        <div class = "modal-content">
            <div class = "modal-header">
                <h4>Update Entity</h4>
            </div>
            <div class = "modal-body">
                <h5 align = "center">ARE YOU SURE WANT TO DEACTIVE ENTITY <i><?php echo $intent[$a]["entity_name"];?></i>? <br/>THIS ACTION CAN'T BE UNDONE</h5>
                <a href = "<?php echo base_url();?>mapping/deactive_entity/<?php echo $intent[$a]["entity_name"];?>" class = "btn btn-danger btn-sm col-lg-12">DEACTIVE</a>
            </div>
        </div>
    </div>
</div>
<?php endfor;?>