<div class="page-header">
    <h1 class="page-title">MASTER MAPPING EDIT</h1>
    <br/>
    <ol class="breadcrumb breadcrumb-arrow">
        <li class="breadcrumb-item"><a href="javascript:void(0)">Home</a></li>
        <li class="breadcrumb-item"><a href="javascript:void(0)">Mapping</a></li>
        <li class="breadcrumb-item">Edit</li>
    </ol>
</div>
<br/>
<div class="page-body col-lg-12">
    <div class="row row-lg">
        <div class="col-xl-12">
            <!-- Example Tabs Left -->
            <div class="example-wrap">
                <div class="nav-tabs-vertical" data-plugin="tabs">
                    <ul class="nav nav-tabs mr-25" role="tablist">
                        <li class="nav-item" role="presentation"><a class="nav-link active" data-toggle="tab" href="#primaryData" aria-controls="primaryData" role="tab">Primary Data</a></li>

                    </ul>
                    <form action = "<?php echo base_url();?>mapping/update_mapping" method = "post" enctype = "multipart/form-data">    
                        <div class="tab-content">
                            <input type = "hidden" name = "id_submit_entity_combination" value = "<?php echo $id_submit_entity_combination;?>">
                            <div class="tab-pane active" id="primaryData" role="tabpanel">
                                <h5>Registered Entity</h5>
                                <table class = "table table-striped table-bordered table-hover">
                                    <thead>
                                        <th style = "width:5%">Add</th>
                                        <th style = "width:5%">Delete</th>
                                        <th>Entity Name</th>
                                        <th>Entity Value</th>
                                    </thead>
                                    <tbody>
                                        <?php for($a = 0; $a<count($reg_entity); $a++):?>
                                        <tr>
                                            <td></td>
                                            <td>
                                                <div class = "checkbox-custom checkbox-primary">
                                                    <input type ="checkbox" name = "check_delete_entity[]" value = "<?php echo $reg_entity[$a]["id_submit_entity_combination_list"];?>">
                                                    <label></label>
                                                </div>
                                            </td>
                                            <td><?php echo $reg_entity[$a]["entity_name"];?></td>
                                            <td><?php echo $reg_entity[$a]["entity_value"];?></td>
                                        </tr>
                                        <?php endfor;?>
                                        <tr id = "addNewButtonContainer">
                                            <td colspan = 4>
                                                <button onclick = "new_entity_row()" type = "button" class = "btn btn-primary btn-sm col-lg-12">+ ADD NEW ENTITY</button>
                                            </td>
                                        </tr>
                                    </tbody>
                                </table>
                                <h5>Registered Dataset</h5>
                                <div>
                                    <a href = "<?php echo base_url();?>dataset/add" class = "btn btn-primary btn-sm" target = "_blank">CREATE NEW DATASET</a>
                                </div>
                                <br/>
                                <table class = "table table-striped table-bordered table-hover">
                                    <thead>
                                        <th style = "width:5%">Add</th>
                                        <th style = "width:5%">Delete</th>
                                        <th>Dataset Name</th>
                                        <th>Dataset Query</th>
                                        <th>Dataset Role</th>
                                    </thead>
                                    <tbody>
                                        <?php for($a = 0; $a<count($reg_dataset); $a++):?>
                                        <tr>
                                            <td></td>
                                            <td>
                                                <div class = "checkbox-custom checkbox-primary">
                                                    <input type ="checkbox" name = "check_delete_dataset[]" value = "<?php echo $reg_dataset[$a]["id_submit_entity_combination_dataset"];?>">
                                                    <label></label>
                                                </div>
                                            </td>
                                            <td><?php echo $reg_dataset[$a]["dataset_name"];?></td>
                                            <td><?php echo $reg_dataset[$a]["dataset_query"];?></td>
                                            <td><?php echo $reg_dataset[$a]["role_dataset"];?></td>
                                        </tr>
                                        <?php endfor;?>
                                        <tr id = "addNewDatasetButtonContainer">
                                            <td colspan = 5>
                                                <button onclick = "new_dataset_row()" type = "button" class = "btn btn-primary btn-sm col-lg-12">+ ADD NEW DATASET</button>
                                            </td>
                                        </tr>
                                    </tbody>
                                </table>
                                <button type = "submit" class = "btn btn-primary btn-sm">SUBMIT</button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
            <div class = "form-group">
                <a href = "<?php echo base_url();?>mapping" class = "btn btn-outline btn-primary btn-sm">BACK</a>
            </div>
            <!-- End Example Tabs Left -->
        </div>
    </div>
</div>