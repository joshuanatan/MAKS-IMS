<script src="<?php echo base_url();?>global/js/Plugin/responsive-tabs.js"></script>
<script src="<?php echo base_url();?>global/js/Plugin/closeable-tabs.js"></script>
<script src="<?php echo base_url();?>global/js/Plugin/tabs.js"></script>