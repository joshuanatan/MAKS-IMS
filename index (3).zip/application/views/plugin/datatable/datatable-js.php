<script src="<?php echo base_url();?>assets/global/vendor/datatables.net/jquery.dataTables.js"></script>
<script src="<?php echo base_url();?>assets/global/vendor/datatables.net-bs4/dataTables.bootstrap4.js"></script>
<script src="<?php echo base_url();?>assets/global/vendor/datatables.net-fixedheader/dataTables.fixedHeader.js"></script>
<script src="<?php echo base_url();?>assets/global/vendor/datatables.net-fixedcolumns/dataTables.fixedColumns.js"></script>
<script src="<?php echo base_url();?>assets/global/vendor/datatables.net-rowgroup/dataTables.rowGroup.js"></script>
<script src="<?php echo base_url();?>assets/global/vendor/datatables.net-scroller/dataTables.scroller.js"></script>
<script src="<?php echo base_url();?>assets/global/vendor/datatables.net-buttons/dataTables.buttons.js"></script>
<script src="<?php echo base_url();?>assets/global/vendor/datatables.net-buttons/buttons.html5.js"></script>
<script src="<?php echo base_url();?>assets/global/vendor/datatables.net-buttons/buttons.flash.js"></script>
<script src="<?php echo base_url();?>assets/global/vendor/datatables.net-buttons/buttons.print.js"></script>
<script src="<?php echo base_url();?>assets/global/vendor/datatables.net-buttons/buttons.colVis.js"></script>
<script src="<?php echo base_url();?>assets/global/vendor/datatables.net-buttons-bs4/buttons.bootstrap4.js"></script>
<script src="<?php echo base_url();?>assets/global/vendor/asrange/jquery-asRange.min.js"></script>
<script src="<?php echo base_url();?>assets/global/vendor/bootbox/bootbox.js"></script>
<script src="<?php echo base_url();?>assets/global/js/Plugin/datatables.js"></script>
<!--<script src="<?php echo base_url();?>assets/examples/js/tables/datatable.js"></script>-->

