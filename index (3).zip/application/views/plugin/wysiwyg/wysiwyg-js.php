<script src="<?php echo base_url();?>global/vendor/summernote/summernote.min.js"></script>
<script src="<?php echo base_url();?>global/js/Plugin/summernote.js"></script>
<script src="<?php echo base_url();?>assets/examples/js/forms/editor-summernote.js"></script>