<!-- Page -->
<script src="<?php echo base_url();?>global/js/Plugin/sticky-header.js"></script>
<script src="<?php echo base_url();?>global/js/Plugin/action-btn.js"></script>
<script src="<?php echo base_url();?>global/js/Plugin/asselectable.js"></script>
<script src="<?php echo base_url();?>global/js/Plugin/editlist.js"></script>
<script src="<?php echo base_url();?>global/js/Plugin/aspaginator.js"></script>
<script src="<?php echo base_url();?>global/js/Plugin/animate-list.js"></script>
<script src="<?php echo base_url();?>global/js/Plugin/jquery-placeholder.js"></script>
<script src="<?php echo base_url();?>global/js/Plugin/material.js"></script>
<script src="<?php echo base_url();?>global/js/Plugin/selectable.js"></script>
<script src="<?php echo base_url();?>global/js/Plugin/bootbox.js"></script>
<script src="<?php echo base_url();?>assets/js/BaseApp.js"></script>
<script src="<?php echo base_url();?>assets/js/App/Contacts.js"></script>

<script src="<?php echo base_url();?>assets/examples/js/apps/contacts.js"></script>

<!-- Plugins -->
<script src="<?php echo base_url();?>global/vendor/slidepanel/jquery-slidePanel.js"></script>
<script src="<?php echo base_url();?>global/vendor/aspaginator/jquery-asPaginator.min.js"></script>
<script src="<?php echo base_url();?>global/vendor/jquery-placeholder/jquery.placeholder.js"></script>
<script src="<?php echo base_url();?>global/vendor/bootbox/bootbox.js"></script>