<script src="<?php echo base_url();?>global/vendor/webui-popover/jquery.webui-popover.min.js"></script>
<script src="<?php echo base_url();?>global/vendor/toolbar/jquery.toolbar.js"></script>
<script src="<?php echo base_url();?>global/js/Plugin/webui-popover.js"></script>
<script src="<?php echo base_url();?>global/js/Plugin/toolbar.js"></script>
<script src="<?php echo base_url();?>assets/examples/js/uikit/tooltip-popover.js"></script>