<script src="<?php echo base_url();?>global/vendor/toastr/toastr.js"></script>
<script src="<?php echo base_url();?>global/js/Plugin/toastr.js"></script>