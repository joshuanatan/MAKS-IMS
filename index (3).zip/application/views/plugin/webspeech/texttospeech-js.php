
<script src="<?php echo base_url();?>assets/js/texttospeech/latinze.js"></script>
<script src="<?php echo base_url();?>assets/js/texttospeech/computer_speak.js?2014"></script>