<link rel="stylesheet" href="<?php echo base_url();?>assets/global/vendor/bootstrap-select/bootstrap-select.css">
<link rel="stylesheet" href="<?php echo base_url();?>assets/global/vendor/jquery-selective/jquery-selective.css">
<link rel="stylesheet" href="<?php echo base_url();?>assets/global/vendor/bootstrap-datepicker/bootstrap-datepicker.css">
<link rel="stylesheet" href="<?php echo base_url();?>assets/global/vendor/bootstrap-markdown/bootstrap-markdown.css">