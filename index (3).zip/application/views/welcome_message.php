<?php if($this->session->status_login == "success"):?>
<div class = "alert alert-success">
    <?php echo $this->session->msg_login;?>
</div>
<?php elseif($this->session->status_login == "error"):?>
<div class = "alert alert-danger">
    <?php echo $this->session->msg_login;?>
</div>
<?php endif;?>
<h2>WELCOME TO <i>MYSQL QUERY BUILDER</i> ADMINISTRATIVE PAGE</h2>
<br/>
<h3>Quick Brief</h3>
<hr/>
<h4>The main purpose of <i>MySQL Query Builder</i> is to manage the mapping between the intent & entity combination and dataset.</h4>
<h5><i>MySQL Query Builder</i> is intended to memorize every intent & entity combination and dataset mapping in database with MySQL engine. After the speech is extracted, the intent and entity will be mapped to their database driver query builder, this module is on of the database driver query builder. The module will generates dataset query and other related dataset</h5>