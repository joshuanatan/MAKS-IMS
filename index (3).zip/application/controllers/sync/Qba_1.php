<?php
class Qba_1 extends CI_Controller{
    private $log_id;
    public function __construct(){
        parent::__construct();
        $this->log_id = "QBA_1";
    }
    private function get_module_endpoint($function){
        $where = array(
            "service_name" => $function,
            "module_connection_log_id" => strtoupper($this->log_id)
        );
        $field = array(
            "service_name","service_url","service_method","service_input","service_output","module_connection_token"
        );
        $result = selectRow("detail_module_endpoint",$where,$field);
        $result_array = $result->result_array();
        return $result_array;
    }
    public function get_intent_entity(){
        $function = "get_intent_entity";
        $last_request = get_log($this->log_id,$function);

        $module_detail = $this->get_module_endpoint($function);
        $url = $module_detail[0]["service_url"].rawurlencode($last_request);
        $header = array(
            "client-token:".$module_detail[0]["module_connection_token"]
        );
        $respond = $this->curl->get($url,$header);
        if($respond){
            if($respond["err"]){
                $msg = $respond["err"];
                $this->session->set_flashdata("status_curl","error");
                $this->session->set_flashdata("msg_curl",$msg);
                log_sync($this->log_id,$function,"error",$msg);
            }
            else{
                $msg = "Request is successfully made";
                $this->session->set_flashdata("status_curl","success");
                $this->session->set_flashdata("msg_curl",$msg);

                $respond = json_decode($respond["response"],true);

                if(array_key_exists("error",$respond)){
                    $msg = $respond["msg"];
                    $this->session->set_flashdata("status_sync","error");
                    $this->session->set_flashdata("msg_sync",$msg);
                    log_sync($this->log_id,$function,"error",$respond["msg"]);
                }
                else{
                    $msg = $respond["msg"];
                    $this->session->set_flashdata("status_sync","success");
                    $this->session->set_flashdata("msg_sync",$msg);
                    log_sync($this->log_id,$function,$respond["status"],$respond["msg"]);
                    if(is_array($respond["intent_entity_list"])){
                        for($a = 0; $a<count($respond["intent_entity_list"]); $a++){
                            $where = array(
                                "entity" => $respond["intent_entity_list"][$a]["entity_value"]
                            );
                            $field = array(
                                "id_submit_entity"
                            );
                            $result = selectRow("tbl_entity",$where,$field);
                            if(!$result->num_rows() > 0){
                                $data = array(
                                    "entity" => $respond["intent_entity_list"][$a]["entity_value"],
                                    "entity_category" => $respond["intent_entity_list"][$a]["entity_name"],
                                    "status_aktif_entity" => 1,
                                    "tgl_entity_add" => date("Y-m-d H:i:s"),
                                    "id_user_entity_add" => 0
                                );
                                insertRow("tbl_entity",$data);
                            }
                        }
                    }
                }
            }
        }
        else{
            $msg = "Error with CURL, No return message. Contact Developer";
            $this->session->set_flashdata("status_curl","error");
            $this->session->set_flashdata("msg_curl",$msg);
            log_sync($this->log_id,$function,"error",$msg);
        }
    }
}
?>
<script type="text/javascript">
close()
</script>