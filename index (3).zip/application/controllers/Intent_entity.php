<?php
class Intent_entity extends CI_Controller{
    private $log_id = "QBA_1";
    public function __construct(){
        parent::__construct();
    }
    public function index(){
        $this->check_session();
        //$this->get_intent_entity();
        $where = array(
            "entity_category !=" => null,
            "status_aktif_entity <" => 2
        );
        $field = array(
            "id_submit_entity","entity","entity_category","status_aktif_entity","tgl_entity_add","tgl_entity_edit"
        );
        $result = selectRow("tbl_entity",$where,$field);
        $data["entity"] = $result->result_array();

        $this->page_generator->req();
        $this->load->view("plugin/datatable/datatable-css");
        $this->page_generator->head_close();
        $this->page_generator->navbar();
        $this->page_generator->content_open();
        $this->load->view("intent_entity/v_intent_entity",$data);
        $this->page_generator->close();
        $this->load->view("plugin/datatable/datatable-js");
        $this->load->view("intent_entity/v_intent_entity_js");
    }
    public function recycle_bin(){
        $this->check_session();
        $where = array(
            "entity_category !=" => null,
            "status_aktif_entity" => 2
        );
        $field = array(
            "id_submit_entity","entity","entity_category","status_aktif_entity","tgl_entity_add","tgl_entity_edit"
        );
        $result = selectRow("tbl_entity",$where,$field);
        $data["entity"] = $result->result_array();

        $this->page_generator->req();
        $this->load->view("plugin/datatable/datatable-css");
        $this->page_generator->head_close();
        $this->page_generator->navbar();
        $this->page_generator->content_open();
        $this->load->view("intent_entity/v_intent_entity_recycle_bin",$data);
        $this->page_generator->close();
        $this->load->view("plugin/datatable/datatable-js");
        $this->load->view("intent_entity/v_intent_entity_js");
    }
    public function insert_entity(){
        $this->check_session();
        $checks = $this->input->post("checks");
        if($checks != ""){
            foreach($checks as $a){
                $data = array(
                    "entity" => $this->input->post("entity".$a),
                    "entity_category" => $this->input->post("entity_category".$a),
                    "status_aktif_entity" => 1,
                    "tgl_entity_add" => date("Y-m-d H:i:s"),
                    "id_user_entity_add" => $this->session->id_user,
                );
                insertRow("tbl_entity",$data);
                $msg = "Ticked data is successfully added to database";
                $this->session->set_flashdata("status_intent_entity","success");
                $this->session->set_flashdata("msg_intent_entity",$msg);
            }
        }
        else{
            $msg = "Need to tick the checkbox before submitting";
            $this->session->set_flashdata("status_intent_entity","error");
            $this->session->set_flashdata("msg_intent_entity",$msg);
        }
        redirect("intent_entity");
    }
    public function update_intent_entity(){
        $this->check_session();
        $where = array(
            "id_submit_entity" => $this->input->post("id_submit_entity")
        );
        $data = array(
            "entity" => $this->input->post("entity"),
            "entity_category" => $this->input->post("entity_category"),
            "tgl_entity_edit" => date("Y-m-d H:i:s"),
            "id_user_entity_edit" => $this->session->id_user
        );
        updateRow("tbl_entity",$data,$where);
        $msg = "Data is successfully updated to database";
        $this->session->set_flashdata("status_intent_entity","success");
        $this->session->set_flashdata("msg_intent_entity",$msg);
        redirect("intent_entity");
    }
    public function update_intent_entity_batch(){
        $this->check_session();
        $update_checks = $this->input->post("update_checks");
        if($update_checks != ""){
            foreach($update_checks as $a){
                $where = array(
                    "id_submit_entity" => $a
                );
                $data = array(
                    "entity_category" => $this->input->post("entity_category".$a),
                    "tgl_entity_edit" => date("Y-m-d H:i:s"),
                    "id_user_entity_edit" => $this->session->id_user
                );
                updateRow("tbl_entity",$data,$where);
            }
            $msg = "Data is successfully updated to database";
            $this->session->set_flashdata("status_intent_entity","success");
            $this->session->set_flashdata("msg_intent_entity",$msg);
        }
        else{
            $msg = "Need to tick the checkbox before submitting";
            $this->session->set_flashdata("status_intent_entity","error");
            $this->session->set_flashdata("msg_intent_entity",$msg);
        }
        redirect("intent_entity");
    }
    public function deactive($id_submit_entity){
        $this->check_session();
        $where = array(
            "id_submit_entity" => $id_submit_entity
        );
        $data = array(
            "status_aktif_entity" => 0,
            "tgl_entity_delete" => date("Y-m-d H:i:s"),
            "id_user_entity_delete" => $this->session->id_user
        );
        updateRow("tbl_entity",$data,$where);
        $msg = "Data is successfully deactivated";
        $this->session->set_flashdata("status_intent_entity","error");
        $this->session->set_flashdata("msg_intent_entity",$msg);
        redirect("intent_entity");
    }
    public function delete($id_submit_entity){
        $this->check_session();
        $where = array(
            "id_submit_entity" => $id_submit_entity
        );
        $data = array(
            "status_aktif_entity" => 2,
            "tgl_entity_delete" => date("Y-m-d H:i:s"),
            "id_user_entity_delete" => $this->session->id_user
        );
        updateRow("tbl_entity",$data,$where);
        $msg = "Data is successfully deactivated";
        $this->session->set_flashdata("status_intent_entity","error");
        $this->session->set_flashdata("msg_intent_entity",$msg);
        redirect("intent_entity");
    }
    public function activate($id_submit_entity){
        $this->check_session();
        $where = array(
            "id_submit_entity" => $id_submit_entity
        );
        $data = array(
            "status_aktif_entity" => 1,
            "tgl_entity_edit" => date("Y-m-d H:i:s"),
            "id_user_entity_edit" => $this->session->id_user
        );
        updateRow("tbl_entity",$data,$where);
        $msg = "Data is successfully deactivated";
        $this->session->set_flashdata("status_intent_entity","success");
        $this->session->set_flashdata("msg_intent_entity",$msg);
        redirect("intent_entity");
    }
    private function check_session(){
		if($this->session->id_user == ""){
			$msg = "Session Expired";	
			$this->session->set_flashdata("status_login","error");
			$this->session->set_flashdata("msg_login",$msg);
			redirect("welcome");
		}
    }
    private function get_module_endpoint($function){
        $where = array(
            "service_name" => $function,
            "module_connection_log_id" => strtoupper($this->log_id)
        );
        $field = array(
            "service_name","service_url","service_method","service_input","service_output","module_connection_token"
        );
        $result = selectRow("detail_module_endpoint",$where,$field);
        $result_array = $result->result_array();
        return $result_array;
    }
    public function get_intent_entity(){
        $function = "get_intent_entity";
        $last_request = get_log($this->log_id,$function);

        $module_detail = $this->get_module_endpoint($function);
        $url = $module_detail[0]["service_url"].rawurlencode($last_request);
        $header = array(
            "client-token:".$module_detail[0]["module_connection_token"]
        );
        $respond = $this->curl->get($url,$header);
        if($respond){
            if($respond["err"]){
                $msg = $respond["err"];
                $this->session->set_flashdata("status_curl","error");
                $this->session->set_flashdata("msg_curl",$msg);
                log_sync($this->log_id,$function,"error",$msg);
            }
            else{
                $msg = "Request is successfully made";
                $this->session->set_flashdata("status_curl","success");
                $this->session->set_flashdata("msg_curl",$msg);

                $respond = json_decode($respond["response"],true);

                if(array_key_exists("error",$respond)){
                    $msg = $respond["msg"];
                    $this->session->set_flashdata("status_sync","error");
                    $this->session->set_flashdata("msg_sync",$msg);
                    log_sync($this->log_id,$function,"error",$respond["msg"]);
                }
                else{
                    $msg = $respond["msg"];
                    $this->session->set_flashdata("status_sync","success");
                    $this->session->set_flashdata("msg_sync",$msg);
                    log_sync($this->log_id,$function,$respond["status"],$respond["msg"]);
                    if(is_array($respond["intent_entity_list"])){
                        for($a = 0; $a<count($respond["intent_entity_list"]); $a++){
                            $where = array(
                                "entity" => $respond["intent_entity_list"][$a]["entity_value"]
                            );
                            $field = array(
                                "id_submit_entity"
                            );
                            $result = selectRow("tbl_entity",$where,$field);
                            if(!$result->num_rows() > 0){
                                $data = array(
                                    "entity" => $respond["intent_entity_list"][$a]["entity_value"],
                                    "entity_category" => $respond["intent_entity_list"][$a]["entity_name"],
                                    "status_aktif_entity" => 1,
                                    "tgl_entity_add" => date("Y-m-d H:i:s"),
                                    "id_user_entity_add" => 0
                                );
                                insertRow("tbl_entity",$data);
                            }
                        }
                    }
                }
            }
        }
        else{
            $msg = "Error with CURL, No return message. Contact Developer";
            $this->session->set_flashdata("status_curl","error");
            $this->session->set_flashdata("msg_curl",$msg);
            log_sync($this->log_id,$function,"error",$msg);
        }
    }
}
?>