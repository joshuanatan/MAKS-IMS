<?php
class Formula extends CI_Controller{
    public function get_db_driver_formula_list(){
        $where = array(
            "id_db_driver" => $this->input->post("id_db_driver")
        );
        $field = array(
            "id_submit_query_formula","nama_formula"
        );
        $result = selectRow("tbl_query_formula",$where,$field);
        $data = $result->result_array();
        echo json_encode($data);
    }
    
    public function get_driver_formula_element(){
        $where = array(
            "id_formula" => $this->input->post("id_formula")
        );
        $field = array(
            "formula_element_name"
        );
        $result = selectRow("tbl_formula_element",$where,$field,"","","formula_element_role","ASC");
        $data = $result->result_array();
        echo json_encode($data);
    }
    public function delete_formula_element(){
        $where = array(
            "id_submit_formula_element" => $this->input->post("id_submit_element_query_formula")
        );
        $data = array(
            "status_aktif_formula_element" => 0
        );
        updateRow("tbl_formula_element",$data,$where);
        echo json_encode("success");
    }
}
?>